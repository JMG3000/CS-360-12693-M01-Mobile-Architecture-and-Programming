package com.example.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * Sends zero-stock SMS alerts only when permission has been granted.
 */
public class SmsNotificationHelper {

    private static final String TAG = "SmsNotification";

    private final Context context;

    public SmsNotificationHelper(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean deviceSupportsSms() {
        return context.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING
        );
    }

    public boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    public boolean sendZeroStockAlert(
            String phoneNumber,
            InventoryItem item
    ) {
        if (!deviceSupportsSms() ||
                !hasSmsPermission() ||
                phoneNumber == null ||
                phoneNumber.trim().isEmpty()) {
            return false;
        }

        String message =
                "Inventory alert: " +
                        item.getName() +
                        " (" +
                        item.getSku() +
                        ") is out of stock.";

        try {
            SmsManager smsManager =
                    context.getSystemService(SmsManager.class);

            if (smsManager == null) {
                return false;
            }

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            return true;
        } catch (SecurityException | IllegalArgumentException exception) {
            Log.e(TAG, "Unable to send zero-stock SMS alert.", exception);
            return false;
        }
    }
}