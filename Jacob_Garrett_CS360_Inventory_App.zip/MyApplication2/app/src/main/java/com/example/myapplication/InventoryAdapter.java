package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Binds SQLite inventory records to item_inventory_row.xml.
 */
public class InventoryAdapter extends
        RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    public interface InventoryActionListener {
        void onIncreaseQuantity(InventoryItem item);
        void onDecreaseQuantity(InventoryItem item);
        void onDeleteItem(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private final InventoryActionListener actionListener;

    public InventoryAdapter(InventoryActionListener actionListener) {
        this.actionListener = actionListener;
    }

    public void replaceItems(List<InventoryItem> updatedItems) {
        items.clear();
        items.addAll(updatedItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.item_inventory_row,
                parent,
                false
        );

        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull InventoryViewHolder holder,
            int position
    ) {
        InventoryItem item = items.get(position);
        holder.bind(item, actionListener);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {

        private final TextView itemNameText;
        private final TextView quantityText;
        private final TextView skuText;
        private final TextView locationText;
        private final TextView stockStatusText;

        private final MaterialButton decreaseButton;
        private final MaterialButton increaseButton;
        private final MaterialButton deleteButton;

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);

            itemNameText = itemView.findViewById(R.id.textViewItemName);
            quantityText = itemView.findViewById(R.id.textViewQuantity);
            skuText = itemView.findViewById(R.id.textViewSku);
            locationText = itemView.findViewById(R.id.textViewLocation);
            stockStatusText =
                    itemView.findViewById(R.id.textViewStockStatus);

            decreaseButton =
                    itemView.findViewById(R.id.buttonDecreaseQuantity);
            increaseButton =
                    itemView.findViewById(R.id.buttonIncreaseQuantity);
            deleteButton = itemView.findViewById(R.id.buttonDeleteItem);
        }

        void bind(
                InventoryItem item,
                InventoryActionListener listener
        ) {
            itemNameText.setText(item.getName());
            quantityText.setText("Qty: " + item.getQuantity());
            skuText.setText("SKU: " + item.getSku());
            locationText.setText("Location: " + item.getLocation());

            updateStockStatus(item);

            decreaseButton.setOnClickListener(
                    view -> listener.onDecreaseQuantity(item)
            );

            increaseButton.setOnClickListener(
                    view -> listener.onIncreaseQuantity(item)
            );

            deleteButton.setOnClickListener(
                    view -> listener.onDeleteItem(item)
            );
        }

        private void updateStockStatus(InventoryItem item) {
            if (item.getQuantity() == 0) {
                stockStatusText.setText(R.string.stock_status_out);
                stockStatusText.setBackgroundResource(
                        R.color.inventory_error_container
                );
                stockStatusText.setTextColor(
                        itemView.getContext().getColor(
                                R.color.inventory_on_error_container
                        )
                );
            } else if (item.getQuantity() <= item.getLowStockThreshold()) {
                stockStatusText.setText(R.string.stock_status_low);
                stockStatusText.setBackgroundResource(
                        R.color.inventory_warning_container
                );
                stockStatusText.setTextColor(
                        itemView.getContext().getColor(
                                R.color.inventory_on_warning_container
                        )
                );
            } else {
                stockStatusText.setText(R.string.stock_status_in_stock);
                stockStatusText.setBackgroundResource(
                        R.color.inventory_primary_container
                );
                stockStatusText.setTextColor(
                        itemView.getContext().getColor(
                                R.color.inventory_on_primary_container
                        )
                );
            }
        }
    }
}