package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Handles database-backed login and first-time account creation.
 */
public class MainActivity extends AppCompatActivity {

    private TextInputEditText usernameInput;
    private TextInputEditText passwordInput;
    private InventoryDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new InventoryDatabaseHelper(this);

        usernameInput = findViewById(R.id.editTextUsername);
        passwordInput = findViewById(R.id.editTextPassword);

        MaterialButton loginButton = findViewById(R.id.buttonLogin);
        MaterialButton createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        loginButton.setOnClickListener(view -> attemptLogin());
        createAccountButton.setOnClickListener(view -> createAccount());
    }

    private void attemptLogin() {
        String username = getInputText(usernameInput);
        String password = getInputText(passwordInput);

        if (!credentialsAreComplete(username, password)) {
            Toast.makeText(
                    this,
                    R.string.credentials_required,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (databaseHelper.authenticateUser(username, password)) {
            openInventoryDashboard();
        } else {
            Toast.makeText(
                    this,
                    R.string.login_failed,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void createAccount() {
        String username = getInputText(usernameInput);
        String password = getInputText(passwordInput);

        if (!credentialsAreComplete(username, password)) {
            Toast.makeText(
                    this,
                    R.string.credentials_required,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        boolean accountCreated =
                databaseHelper.createUser(username, password);

        if (accountCreated) {
            Toast.makeText(
                    this,
                    R.string.account_created,
                    Toast.LENGTH_SHORT
            ).show();

            openInventoryDashboard();
        } else {
            Toast.makeText(
                    this,
                    R.string.account_exists,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private boolean credentialsAreComplete(
            String username,
            String password
    ) {
        return !TextUtils.isEmpty(username) &&
                !TextUtils.isEmpty(password);
    }

    private String getInputText(TextInputEditText input) {
        if (input.getText() == null) {
            return "";
        }

        return input.getText().toString().trim();
    }

    private void openInventoryDashboard() {
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        databaseHelper.close();
        super.onDestroy();
    }
}