package com.example.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.InventoryActionListener {
    private static final String PREFERENCES_NAME = "inventory_notification_preferences";
    private static final String PHONE_NUMBER_KEY = "sms_phone_number";
    private static final String SMS_ALERTS_ENABLED_KEY = "sms_alerts_enabled";
    private static final String SMS_SECTION_EXPANDED_KEY = "sms_section_expanded";
    private InventoryDatabaseHelper databaseHelper;
    private InventoryAdapter inventoryAdapter;
    private SmsNotificationHelper smsNotificationHelper;
    private TextInputEditText phoneNumberInput;
    private TextView smsStatusText;
    private MaterialButton smsToggleButton;
    private LinearLayout smsCollapsibleContent;
    private MaterialButton smsSectionToggleButton;
    private SharedPreferences preferences;
    private final ActivityResultLauncher<Intent> addItemLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            loadInventoryItems();
                        }
                    }
            );
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),permissionGranted -> {
                        if (permissionGranted) {
                            enableSmsAlerts();

                        } else {
                            disableSmsAlerts();
                            smsStatusText.setText(R.string.sms_alerts_denied);

                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new InventoryDatabaseHelper(this);
        smsNotificationHelper = new SmsNotificationHelper(this);
        preferences = getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        phoneNumberInput = findViewById(R.id.editTextPhoneNumber);
        smsStatusText = findViewById(R.id.textViewSmsStatus);
        smsToggleButton = findViewById(R.id.buttonEnableSmsAlerts);
        smsCollapsibleContent = findViewById(R.id.smsCollapsibleContent);
        smsSectionToggleButton = findViewById(R.id.buttonToggleSmsSection);

        configureRecyclerView();
        configureButtons();
        restoreSmsPhoneNumber();
        restoreSmsSectionState();
        updateSmsControls();
        loadInventoryItems();

    }


    private void configureRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.recyclerViewInventory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        inventoryAdapter = new InventoryAdapter(this);
        recyclerView.setAdapter(inventoryAdapter);

    }

    private void configureButtons() {
        MaterialButton addItemButton = findViewById(R.id.buttonAddItem);
        smsToggleButton.setOnClickListener(view -> toggleSmsAlerts());
        addItemButton.setOnClickListener(view -> openAddItemScreen());
        smsSectionToggleButton.setOnClickListener(view -> toggleSmsSection());

    }

    private void openAddItemScreen() {
        Intent intent = new Intent(this, AddItemActivity.class);
        addItemLauncher.launch(intent);

    }

    private void loadInventoryItems() {
        inventoryAdapter.replaceItems(databaseHelper.getAllInventoryItems());

    }
    private void toggleSmsSection() {
        boolean isCurrentlyExpanded = smsCollapsibleContent.getVisibility() == View.VISIBLE;
        setSmsSectionExpanded(!isCurrentlyExpanded);
    }

    private void setSmsSectionExpanded(boolean expanded) {
        smsCollapsibleContent.setVisibility(expanded ? View.VISIBLE : View.GONE);
        smsSectionToggleButton.setText(expanded ? R.string.collapse_sms_settings : R.string.expand_sms_settings);
        preferences.edit().putBoolean(SMS_SECTION_EXPANDED_KEY, expanded).apply();
    }

    private void restoreSmsSectionState() {
        boolean sectionExpanded = preferences.getBoolean(SMS_SECTION_EXPANDED_KEY, true);
        setSmsSectionExpanded(sectionExpanded);
    }

    private void toggleSmsAlerts() {
        if (areSmsAlertsEnabled()) {
            disableSmsAlerts();

        } else {
            requestSmsPermissionIfNeeded();

        }

    }

    private void requestSmsPermissionIfNeeded() {
        String phoneNumber = getPhoneNumber();

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, R.string.sms_phone_required, Toast.LENGTH_SHORT).show();
            phoneNumberInput.requestFocus();

            return;

        }

        if (!smsNotificationHelper.deviceSupportsSms()) {
            disableSmsAlerts();
            smsStatusText.setText(R.string.sms_not_supported);

            return;

        }

        saveSmsPhoneNumber(phoneNumber);

        if (smsNotificationHelper.hasSmsPermission()) {
            enableSmsAlerts();

        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);

        }
    }

    private void enableSmsAlerts() {
        String phoneNumber = getPhoneNumber();

        if (TextUtils.isEmpty(phoneNumber)) {
            disableSmsAlerts();
            Toast.makeText(this, R.string.sms_phone_required, Toast.LENGTH_SHORT).show();

            return;

        }

        saveSmsPhoneNumber(phoneNumber);
        preferences.edit().putBoolean(SMS_ALERTS_ENABLED_KEY, true).apply();
        updateSmsControls();

    }

    private void disableSmsAlerts() {
        preferences.edit().putBoolean(SMS_ALERTS_ENABLED_KEY, false).apply();
        updateSmsControls();

    }

    private void updateSmsControls() {
        if (!smsNotificationHelper.deviceSupportsSms()) {
            preferences.edit().putBoolean(SMS_ALERTS_ENABLED_KEY, false).apply();
            smsToggleButton.setText(R.string.enable_sms_alerts);
            smsStatusText.setText(R.string.sms_not_supported);

            return;

        }

        if (!smsNotificationHelper.hasSmsPermission()
                && areSmsAlertsEnabled()) {

            preferences.edit().putBoolean(SMS_ALERTS_ENABLED_KEY, false).apply();
        }

        if (areSmsAlertsEnabled()) {
            smsToggleButton.setText(R.string.disable_sms_alerts);
            smsStatusText.setText(R.string.sms_alerts_enabled);

        } else {
            smsToggleButton.setText(R.string.enable_sms_alerts);
            smsStatusText.setText(R.string.sms_alerts_disabled);

        }
    }

    private boolean areSmsAlertsEnabled() {
        return preferences.getBoolean(SMS_ALERTS_ENABLED_KEY, false);
    }

    private void saveSmsPhoneNumber(String phoneNumber) {
        preferences.edit().putString(PHONE_NUMBER_KEY, phoneNumber).apply();

    }

    private void restoreSmsPhoneNumber() {
        String savedNumber = preferences.getString(PHONE_NUMBER_KEY, "");
        phoneNumberInput.setText(savedNumber);

    }

    private String getPhoneNumber() {
        if (phoneNumberInput.getText() == null) {
            return "";
        }

        return phoneNumberInput.getText().toString().trim();
    }

    @Override
    public void onIncreaseQuantity(InventoryItem item) {
        int updatedQuantity = item.getQuantity() + 1;
        boolean quantityUpdated = databaseHelper.updateItemQuantity(item.getId(), updatedQuantity);

        if (quantityUpdated) {
            loadInventoryItems();
        }
    }

    @Override
    public void onDecreaseQuantity(InventoryItem item) {
        if (item.getQuantity() == 0) {
            Toast.makeText(this, R.string.quantity_cannot_be_negative, Toast.LENGTH_SHORT).show();
            return;

        }

        int updatedQuantity = item.getQuantity() - 1;
        boolean quantityUpdated = databaseHelper.updateItemQuantity(item.getId(), updatedQuantity);

        if (!quantityUpdated) {
            return;

        }

        if (updatedQuantity == 0) {
            sendZeroStockAlert(item);

        }

        loadInventoryItems();
    }

    @Override
    public void onDeleteItem(InventoryItem item) {
        boolean itemDeleted = databaseHelper.deleteInventoryItem(item.getId());

        if (itemDeleted) {
            Toast.makeText(this, R.string.item_deleted, Toast.LENGTH_SHORT).show();
            loadInventoryItems();

        }
    }

    private void sendZeroStockAlert(InventoryItem originalItem) {
        if (!areSmsAlertsEnabled()) {
            return;

        }

        if (!smsNotificationHelper.hasSmsPermission()) {
            disableSmsAlerts();
            return;

        }

        String savedPhoneNumber = preferences.getString(PHONE_NUMBER_KEY, "");

        if (TextUtils.isEmpty(savedPhoneNumber)) {
            disableSmsAlerts();
            return;

        }

        InventoryItem zeroStockItem = new InventoryItem(
                originalItem.getId(),
                originalItem.getName(),
                originalItem.getSku(),
                0,
                originalItem.getLocation(),
                originalItem.getLowStockThreshold()
        );

        boolean messageSent = smsNotificationHelper.sendZeroStockAlert(savedPhoneNumber, zeroStockItem);

        if (messageSent) {
            Toast.makeText(this, R.string.sms_alert_sent, Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(this, R.string.sms_alert_failed, Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (inventoryAdapter != null) {
            loadInventoryItems();
        }

        if (preferences != null
                && smsNotificationHelper != null
                && smsToggleButton != null) {

            updateSmsControls();
        }
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}