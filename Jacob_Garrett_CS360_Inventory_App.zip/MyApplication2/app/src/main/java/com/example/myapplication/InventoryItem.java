package com.example.myapplication;

/**
 * Represents one inventory record stored in the SQLite database.
 */
public class InventoryItem {

    private final long id;
    private final String name;
    private final String sku;
    private final int quantity;
    private final String location;
    private final int lowStockThreshold;

    public InventoryItem(
            long id,
            String name,
            String sku,
            int quantity,
            String location,
            int lowStockThreshold
    ) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.quantity = quantity;
        this.location = location;
        this.lowStockThreshold = lowStockThreshold;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getLocation() {
        return location;
    }

    public int getLowStockThreshold() {
        return lowStockThreshold;
    }
}