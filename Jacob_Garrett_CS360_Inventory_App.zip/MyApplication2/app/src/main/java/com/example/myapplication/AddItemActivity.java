package com.example.myapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AddItemActivity extends AppCompatActivity {

    private TextInputEditText itemNameInput;
    private TextInputEditText skuInput;
    private TextInputEditText quantityInput;
    private TextInputEditText locationInput;
    private TextInputEditText thresholdInput;

    private InventoryDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new InventoryDatabaseHelper(this);

        itemNameInput = findViewById(R.id.editTextItemName);
        skuInput = findViewById(R.id.editTextSku);
        quantityInput = findViewById(R.id.editTextQuantity);
        locationInput = findViewById(R.id.editTextLocation);
        thresholdInput = findViewById(R.id.editTextThreshold);

        MaterialButton saveButton = findViewById(R.id.buttonSaveItem);
        MaterialButton cancelButton =
                findViewById(R.id.buttonCancelAddItem);

        saveButton.setOnClickListener(view -> saveInventoryItem());
        cancelButton.setOnClickListener(view -> finish());
    }

    private void saveInventoryItem() {
        String name = getInputText(itemNameInput);
        String sku = getInputText(skuInput).toUpperCase();
        String quantityText = getInputText(quantityInput);
        String location = getInputText(locationInput);
        String thresholdText = getInputText(thresholdInput);

        if (TextUtils.isEmpty(name) ||
                TextUtils.isEmpty(sku) ||
                TextUtils.isEmpty(quantityText) ||
                TextUtils.isEmpty(location) ||
                TextUtils.isEmpty(thresholdText)) {

            Toast.makeText(
                    this,
                    R.string.item_fields_required,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int quantity;
        int threshold;

        try {
            quantity = Integer.parseInt(quantityText);
            threshold = Integer.parseInt(thresholdText);
        } catch (NumberFormatException exception) {
            Toast.makeText(
                    this,
                    R.string.numbers_must_be_valid,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (quantity < 0 || threshold < 0) {
            Toast.makeText(
                    this,
                    R.string.numbers_must_be_valid,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        long newItemId = databaseHelper.insertInventoryItem(
                name,
                sku,
                quantity,
                location,
                threshold
        );

        if (newItemId != -1) {
            Toast.makeText(
                    this,
                    R.string.item_saved,
                    Toast.LENGTH_SHORT
            ).show();

            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(
                    this,
                    R.string.sku_already_exists,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private String getInputText(TextInputEditText input) {
        if (input.getText() == null) {
            return "";
        }

        return input.getText().toString().trim();
    }

    @Override
    protected void onDestroy() {
        databaseHelper.close();
        super.onDestroy();
    }
}