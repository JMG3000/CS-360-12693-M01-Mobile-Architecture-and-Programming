package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "InventoryDatabase";

    private static final String DATABASE_NAME = "inventory_tracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String USER_COLUMN_ID = "id";
    private static final String USER_COLUMN_USERNAME = "username";
    private static final String USER_COLUMN_PASSWORD = "password";

    private static final String TABLE_INVENTORY = "inventory_items";
    private static final String ITEM_COLUMN_ID = "id";
    private static final String ITEM_COLUMN_NAME = "name";
    private static final String ITEM_COLUMN_SKU = "sku";
    private static final String ITEM_COLUMN_QUANTITY = "quantity";
    private static final String ITEM_COLUMN_LOCATION = "location";
    private static final String ITEM_COLUMN_THRESHOLD = "low_stock_threshold";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase database) {
        super.onConfigure(database);
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USER_COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        USER_COLUMN_PASSWORD + " TEXT NOT NULL" +
                        ")";

        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        ITEM_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ITEM_COLUMN_NAME + " TEXT NOT NULL, " +
                        ITEM_COLUMN_SKU + " TEXT NOT NULL UNIQUE, " +
                        ITEM_COLUMN_QUANTITY + " INTEGER NOT NULL DEFAULT 0, " +
                        ITEM_COLUMN_LOCATION + " TEXT NOT NULL, " +
                        ITEM_COLUMN_THRESHOLD + " INTEGER NOT NULL DEFAULT 0" +
                        ")";

        database.execSQL(createUsersTable);
        database.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase database,
            int oldVersion,
            int newVersion
    ) {
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(database);
    }

    public boolean createUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(USER_COLUMN_USERNAME, username);
        values.put(USER_COLUMN_PASSWORD, password);

        try {
            long result = getWritableDatabase().insertOrThrow(
                    TABLE_USERS,
                    null,
                    values
            );
            return result != -1;
        } catch (SQLiteConstraintException exception) {
            Log.w(TAG, "User account was not created because the username exists.");
            return false;
        }
    }

    public boolean authenticateUser(String username, String password) {
        String selection =
                USER_COLUMN_USERNAME + " = ? AND " +
                        USER_COLUMN_PASSWORD + " = ?";

        String[] selectionArgs = {username, password};

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{USER_COLUMN_ID},
                selection,
                selectionArgs,
                null,
                null,
                null
        )) {
            return cursor.moveToFirst();
        }
    }

    public long insertInventoryItem(
            String name,
            String sku,
            int quantity,
            String location,
            int lowStockThreshold
    ) {
        ContentValues values = new ContentValues();
        values.put(ITEM_COLUMN_NAME, name);
        values.put(ITEM_COLUMN_SKU, sku);
        values.put(ITEM_COLUMN_QUANTITY, quantity);
        values.put(ITEM_COLUMN_LOCATION, location);
        values.put(ITEM_COLUMN_THRESHOLD, lowStockThreshold);

        try {
            return getWritableDatabase().insertOrThrow(
                    TABLE_INVENTORY,
                    null,
                    values
            );
        } catch (SQLiteConstraintException exception) {
            Log.w(TAG, "Inventory item was not inserted because the SKU exists.");
            return -1;
        }
    }

    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();

        String orderBy = ITEM_COLUMN_NAME + " COLLATE NOCASE ASC";

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                orderBy
        )) {
            int idIndex = cursor.getColumnIndexOrThrow(ITEM_COLUMN_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(ITEM_COLUMN_NAME);
            int skuIndex = cursor.getColumnIndexOrThrow(ITEM_COLUMN_SKU);
            int quantityIndex =
                    cursor.getColumnIndexOrThrow(ITEM_COLUMN_QUANTITY);
            int locationIndex =
                    cursor.getColumnIndexOrThrow(ITEM_COLUMN_LOCATION);
            int thresholdIndex =
                    cursor.getColumnIndexOrThrow(ITEM_COLUMN_THRESHOLD);

            while (cursor.moveToNext()) {
                InventoryItem item = new InventoryItem(
                        cursor.getLong(idIndex),
                        cursor.getString(nameIndex),
                        cursor.getString(skuIndex),
                        cursor.getInt(quantityIndex),
                        cursor.getString(locationIndex),
                        cursor.getInt(thresholdIndex)
                );

                items.add(item);
            }
        }

        return items;
    }

    public boolean updateItemQuantity(long itemId, int newQuantity) {
        if (newQuantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(ITEM_COLUMN_QUANTITY, newQuantity);

        int updatedRows = getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                ITEM_COLUMN_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        return updatedRows == 1;
    }

    public boolean deleteInventoryItem(long itemId) {
        int deletedRows = getWritableDatabase().delete(
                TABLE_INVENTORY,
                ITEM_COLUMN_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        return deletedRows == 1;
    }
}